# 2018/10/11 リリースについて

## 領域の描画について
以下のcv2.rectangleの第2引数、第3引数に座標を入力((x1,y1,),(x2,y2))

397行目
    cv2.rectangle(
        frame,
        ((center1_width-threshold-(share_margin)),
         (center_height-threshold-(share_margin))), # start coordinates
        ((center1_width+threshold+(share_margin)),
         (center_height+threshold+(share_margin))), # end coordinates
        (0,0,255),
        3
    )
    cv2.rectangle(
        frame,
        ((center2_width-threshold-(share_margin)),
         (center_height-threshold-(share_margin))), # start coordinates
        ((center2_width+threshold+(share_margin)),
         (center_height+threshold+(share_margin))), # end coordinates 
        (0,0,255),
        3
    )
    cv2.rectangle(
        frame,
        ((center3_width-threshold-(share_margin)),
         (center_height-threshold-(share_margin))), # start coordinates
        ((center3_width+threshold+(share_margin)),
         (center_height+threshold+(share_margin))), # end coordinates
        (0,0,255),
        3
    )


## 画像の推論する領域について
以下のbbox1-3の値を変更((x1,y1,),(x2,y2))
434行目
    # ROI
    bbox1 = frame[center_height-threshold:center_height+threshold,
                  center1_width-threshold:center1_width+threshold]
    bbox2 = frame[center_height-threshold:center_height+threshold,
                  center2_width-threshold:center2_width+threshold]
    bbox3 = frame[center_height-threshold:center_height+threshold,
                  center3_width-threshold:center3_width+threshold]









