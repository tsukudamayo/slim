﻿INSERT INTO Btob_Client_Contracts_Layout (btob_client_contract_id,btob_client_name_disp,original_header_flag,header_background_color,logo_alt,logo_link_url,logo_link_target_flag,btn1_flag,btn1_alt,btn1_url,btn1_target_flag,btn2_flag,btn2_alt,btn2_url,btn2_target_flag,original_footer_flag,footer_background_color,weekcook_link_flag,addthis_flag,addthis_id,footer_html,original_recipe_tpl_flag,btob_design_theme_id,still_disp_flag,admin_note,created_id,created_at,updated_id,updated_at) VALUES ('1','ピタデリ','0','      ','PitaDeli',NULL,'0','0','',NULL,'0','0','',NULL,'0','0','      ','0','0','','    <p>最新の献立情報を、毎週お届け！</p>
    <div class=""ta-c"">
      <p class=""fc-vivid07 my1""><strong>ユニーチラシアプリをダウンロード</strong></p>
      <a class=""mt2 mb4 inline-block"" href=""//play.google.com/store/apps/details?id=jp.co.uny.apps.chirashi.android"" target=""_blank"" onclick=""gWspGA.sendEvent('apita_136'',''click'',''apita_google');""><img src=""/beu/apita_136/common/images/b_googleplay.gif"" alt=""ANDROID APP ON Google play"" /></a><br />
      <a class=""inline-block"" href=""//itunes.apple.com/jp/app/id720063168"" target=""_blank"" onclick=""gWspGA.sendEvent('apita_136'',''click'',''apita_app');""><img src=""/beu/apita_136/common/images/b_appstore.gif"" alt=""Avaiable on the App Store"" /></a>
    </div>','0','1','0','','6','2017-05-11 15:58:18.000','6','2017-05-11 15:58:18.000');
INSERT INTO Btob_Client_Contracts_Layout (btob_client_contract_id,btob_client_name_disp,original_header_flag,header_background_color,logo_alt,logo_link_url,logo_link_target_flag,btn1_flag,btn1_alt,btn1_url,btn1_target_flag,btn2_flag,btn2_alt,btn2_url,btn2_target_flag,original_footer_flag,footer_background_color,weekcook_link_flag,addthis_flag,addthis_id,footer_html,original_recipe_tpl_flag,btob_design_theme_id,still_disp_flag,admin_note,created_id,created_at,updated_id,updated_at) VALUES ('3','ＥＳハウジング','0','      ','サンプル',NULL,'0','0','',NULL,'0','0','',NULL,'0','0','      ','0','0','','<div class=""copy"">(c) Panasonic Corporation</div>','0','1','0','','6','2017-05-29 14:39:37.000','6','2017-05-29 15:43:30.000');
INSERT INTO Btob_Client_Contracts_Layout (btob_client_contract_id,btob_client_name_disp,original_header_flag,header_background_color,logo_alt,logo_link_url,logo_link_target_flag,btn1_flag,btn1_alt,btn1_url,btn1_target_flag,btn2_flag,btn2_alt,btn2_url,btn2_target_flag,original_footer_flag,footer_background_color,weekcook_link_flag,addthis_flag,addthis_id,footer_html,original_recipe_tpl_flag,btob_design_theme_id,still_disp_flag,admin_note,created_id,created_at,updated_id,updated_at) VALUES ('4','特別献立「鰻」','0','      ','weekcook','https://www.weekcook.jp/index.html','0','0','',NULL,'0','0','',NULL,'0','0','      ','0','1','ra-57c79d5d29a5d8e4','    <div class=""copy"">(c) Panasonic Corporation</div>
    <div class=""footer_btn"">
      <a class=""btn smart btn_16"" href=""/terms/""><span class=""btn_none"">利用規約</span></a>
      <a class=""btn smart btn_16"" href=""/terms/member.html""><span class=""btn_none"">会員利用規約</span></a>
      <a class=""btn smart btn_16"" href=""/inquiry/""><span class=""btn_none"">お問い合わせ</span></a>
      <a class=""btn smart btn_16"" href=""//www.panasonic.com/jp/privacy-policy.html"" target=""_blank""><span class=""btn_none"">個人情報保護方針</span></a>
      <a class=""btn smart btn_16"" href=""//questant.jp/q/weekcook"" target=""_blank""><span class=""btn_none"">ご意見・ご感想</span></a>
    </div><!-- /.footer_btn -->','0','1','1','','6','2017-06-27 15:10:34.000','6','2017-06-27 18:33:17.000');
INSERT INTO Btob_Client_Contracts_Layout (btob_client_contract_id,btob_client_name_disp,original_header_flag,header_background_color,logo_alt,logo_link_url,logo_link_target_flag,btn1_flag,btn1_alt,btn1_url,btn1_target_flag,btn2_flag,btn2_alt,btn2_url,btn2_target_flag,original_footer_flag,footer_background_color,weekcook_link_flag,addthis_flag,addthis_id,footer_html,original_recipe_tpl_flag,btob_design_theme_id,still_disp_flag,admin_note,created_id,created_at,updated_id,updated_at) VALUES ('5','季節のおすすめ献立','0','      ','weekcook','https://www.weekcook.jp/index.html','0','0','',NULL,'0','0','',NULL,'0','0','      ','0','1','ra-57c79d5d29a5d8e4','    <div class=""copy"">(c) Panasonic Corporation</div>
    <div class=""footer_btn"">
      <a class=""btn smart btn_16"" href=""/terms/""><span class=""btn_none"">利用規約</span></a>
      <a class=""btn smart btn_16"" href=""/terms/member.html""><span class=""btn_none"">会員利用規約</span></a>
      <a class=""btn smart btn_16"" href=""/inquiry/""><span class=""btn_none"">お問い合わせ</span></a>
      <a class=""btn smart btn_16"" href=""//www.panasonic.com/jp/privacy-policy.html"" target=""_blank""><span class=""btn_none"">個人情報保護方針</span></a>
      <a class=""btn smart btn_16"" href=""//questant.jp/q/weekcook"" target=""_blank""><span class=""btn_none"">ご意見・ご感想</span></a>
    </div><!-- /.footer_btn -->','0','1','1','','6','2017-06-28 10:34:26.000','6','2017-06-28 14:08:38.000');
INSERT INTO Btob_Client_Contracts_Layout (btob_client_contract_id,btob_client_name_disp,original_header_flag,header_background_color,logo_alt,logo_link_url,logo_link_target_flag,btn1_flag,btn1_alt,btn1_url,btn1_target_flag,btn2_flag,btn2_alt,btn2_url,btn2_target_flag,original_footer_flag,footer_background_color,weekcook_link_flag,addthis_flag,addthis_id,footer_html,original_recipe_tpl_flag,btob_design_theme_id,still_disp_flag,admin_note,created_id,created_at,updated_id,updated_at) VALUES ('6','京急百貨店','0','      ','京急百貨店','https://www.weekcook.jp/beu/keikyu/index.html','0','0','',NULL,'0','0','',NULL,'0','0','f5efe3','0','0','','<div class=""ta-c"">
<p class=""fc-mono01 mt1"">各レシピの食材は京急百貨店地下1階＝食品フロアで取り揃えております。店頭ではこのマークが目印です。</p>
<img src=""/beu/keikyu/common/images/egaorecipe_banner_87x159.jpg"" alt=""えがおレシピ"" /><br /><br />
<a class=""inline-block mr2"" href=""/beu/keikyu/sitepolicy.html"">サイトご利用にあたって</a>
<a class=""inline-block"" href=""/beu/keikyu/inquiry.html"">お問い合わせ</a>
</div>','0','1','0','','6','2017-07-11 12:54:57.000','6','2017-08-03 11:00:26.000');
INSERT INTO Btob_Client_Contracts_Layout (btob_client_contract_id,btob_client_name_disp,original_header_flag,header_background_color,logo_alt,logo_link_url,logo_link_target_flag,btn1_flag,btn1_alt,btn1_url,btn1_target_flag,btn2_flag,btn2_alt,btn2_url,btn2_target_flag,original_footer_flag,footer_background_color,weekcook_link_flag,addthis_flag,addthis_id,footer_html,original_recipe_tpl_flag,btob_design_theme_id,still_disp_flag,admin_note,created_id,created_at,updated_id,updated_at) VALUES ('7','まとめづくり料理体験','0','      ','ウィークックナビ','https://www.weekcook.jp/index.html','0','0','',NULL,'0','0','',NULL,'0','0','f5efe3','0','0','','<!-- フッター -->

<footer class=""footer-all"">
  <div class=""footer_wrap"">
    <div class=""addthis_inline_share_toolbox""><!-- シェアボタン --></div>
    <div class=""copy"">(c) Panasonic Corporation</div>
    <div class=""footer_btn"">
      <a class=""btn smart btn_16"" href=""/terms/""><span class=""btn_none"">利用規約</span></a>
      <a class=""btn smart btn_16"" href=""/terms/member.html""><span class=""btn_none"">会員利用規約</span></a>
      <a class=""btn smart btn_16"" href=""/inquiry/""><span class=""btn_none"">お問い合わせ</span></a>
      <a class=""btn smart btn_16"" href=""//www.panasonic.com/jp/privacy-policy.html"" target=""_blank""><span class=""btn_none"">個人情報保護方針</span></a>
      <a class=""btn smart btn_16"" href=""//questant.jp/q/weekcook"" target=""_blank""><span class=""btn_none"">ご意見・ご感想</span></a>
    </div><!-- /.footer_btn -->
  </div><!-- /.footer_wrap -->
</footer><!-- /.footer-all -->
<script type=""text/javascript"" src=""//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-57c79d5d29a5d8e4""></script>

<!-- /フッター -->
','0','1','0','','15','2018-03-22 11:29:12.000','15','2018-05-09 13:26:22.000');
INSERT INTO Btob_Client_Contracts_Layout (btob_client_contract_id,btob_client_name_disp,original_header_flag,header_background_color,logo_alt,logo_link_url,logo_link_target_flag,btn1_flag,btn1_alt,btn1_url,btn1_target_flag,btn2_flag,btn2_alt,btn2_url,btn2_target_flag,original_footer_flag,footer_background_color,weekcook_link_flag,addthis_flag,addthis_id,footer_html,original_recipe_tpl_flag,btob_design_theme_id,still_disp_flag,admin_note,created_id,created_at,updated_id,updated_at) VALUES ('8','Departテスト','0','      ','logo.png','https://www.weekcook.jp/index.html','1','0','',NULL,'0','0','',NULL,'0','0','      ','0','0','f5efe3','<!-- フッター -->

<footer class=""footer-all"">
  <div class=""footer_wrap"">
    <div class=""addthis_inline_share_toolbox""><!-- シェアボタン --></div>
    <div class=""copy"">(c) Panasonic Corporation</div>
    <div class=""footer_btn"">
      <a class=""btn smart btn_16"" href=""/terms/""><span class=""btn_none"">利用規約</span></a>
      <a class=""btn smart btn_16"" href=""/terms/member.html""><span class=""btn_none"">会員利用規約</span></a>
      <a class=""btn smart btn_16"" href=""/inquiry/""><span class=""btn_none"">お問い合わせ</span></a>
      <a class=""btn smart btn_16"" href=""//www.panasonic.com/jp/privacy-policy.html"" target=""_blank""><span class=""btn_none"">個人情報保護方針</span></a>
      <a class=""btn smart btn_16"" href=""//questant.jp/q/weekcook"" target=""_blank""><span class=""btn_none"">ご意見・ご感想</span></a>
    </div><!-- /.footer_btn -->
  </div><!-- /.footer_wrap -->
</footer><!-- /.footer-all -->
<script type=""text/javascript"" src=""//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-57c79d5d29a5d8e4""></script>

<!-- /フッター -->
','0','1','1','','15','2018-05-14 12:49:00.000','15','2018-05-14 12:49:37.000');
