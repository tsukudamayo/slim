INSERT INTO Rcmd_Recipe_List (rcmd_recipe_list_id,recipe_id,created_id,created_at,updated_id,updated_at) VALUES ('1','131','1','2016-03-07 12:57:38.593','1','2016-11-10 11:10:55.420');
INSERT INTO Rcmd_Recipe_List (rcmd_recipe_list_id,recipe_id,created_id,created_at,updated_id,updated_at) VALUES ('2','155','1','2016-03-07 12:57:48.387','1','2016-11-10 11:10:55.420');
INSERT INTO Rcmd_Recipe_List (rcmd_recipe_list_id,recipe_id,created_id,created_at,updated_id,updated_at) VALUES ('3','2137','1','2016-03-07 12:57:58.917','1','2016-11-10 11:10:55.420');
INSERT INTO Rcmd_Recipe_List (rcmd_recipe_list_id,recipe_id,created_id,created_at,updated_id,updated_at) VALUES ('4','308','1','2016-03-07 12:58:09.097','1','2016-11-10 11:10:55.420');
INSERT INTO Rcmd_Recipe_List (rcmd_recipe_list_id,recipe_id,created_id,created_at,updated_id,updated_at) VALUES ('5','2023','1','2016-04-18 10:36:55.470','1','2016-11-10 11:10:55.420');
INSERT INTO Rcmd_Recipe_List (rcmd_recipe_list_id,recipe_id,created_id,created_at,updated_id,updated_at) VALUES ('6','91','1','2016-04-18 10:40:29.027','1','2016-11-10 11:10:55.420');
INSERT INTO Rcmd_Recipe_List (rcmd_recipe_list_id,recipe_id,created_id,created_at,updated_id,updated_at) VALUES ('7','217','1','2016-07-08 03:06:16.187','1','2016-11-10 11:10:55.420');
INSERT INTO Rcmd_Recipe_List (rcmd_recipe_list_id,recipe_id,created_id,created_at,updated_id,updated_at) VALUES ('8','2004','1','2016-07-08 03:06:40.797','1','2016-11-10 11:10:55.420');
