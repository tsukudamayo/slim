INSERT INTO Picture_Type (picture_type_id,picture_type_name,created_id,created_at,updated_id,updated_at) VALUES ('1','完成写真','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Picture_Type (picture_type_id,picture_type_name,created_id,created_at,updated_id,updated_at) VALUES ('2','下準備写真','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Picture_Type (picture_type_id,picture_type_name,created_id,created_at,updated_id,updated_at) VALUES ('3','作り置き写真','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Picture_Type (picture_type_id,picture_type_name,created_id,created_at,updated_id,updated_at) VALUES ('4','工程写真','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
