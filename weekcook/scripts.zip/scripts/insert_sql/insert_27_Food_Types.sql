INSERT INTO Food_Types (food_type_id,food_type_name,created_id,created_at,updated_id,updated_at) VALUES ('1','肉料理','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Food_Types (food_type_id,food_type_name,created_id,created_at,updated_id,updated_at) VALUES ('2','魚料理','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Food_Types (food_type_id,food_type_name,created_id,created_at,updated_id,updated_at) VALUES ('3','野菜料理','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Food_Types (food_type_id,food_type_name,created_id,created_at,updated_id,updated_at) VALUES ('4','卵料理','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Food_Types (food_type_id,food_type_name,created_id,created_at,updated_id,updated_at) VALUES ('5','豆・豆腐料理','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Food_Types (food_type_id,food_type_name,created_id,created_at,updated_id,updated_at) VALUES ('6','麺類','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Food_Types (food_type_id,food_type_name,created_id,created_at,updated_id,updated_at) VALUES ('7','ご飯物','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Food_Types (food_type_id,food_type_name,created_id,created_at,updated_id,updated_at) VALUES ('8','その他','1','2014-04-10 00:00:00.000','1','2014-11-10 17:19:02.000');
