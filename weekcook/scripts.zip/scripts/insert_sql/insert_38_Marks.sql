INSERT INTO Marks (mark_id,mark_name,created_id,created_at,updated_id,updated_at) VALUES ('1','★','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Marks (mark_id,mark_name,created_id,created_at,updated_id,updated_at) VALUES ('2','Ａ','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Marks (mark_id,mark_name,created_id,created_at,updated_id,updated_at) VALUES ('3','Ｂ','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
