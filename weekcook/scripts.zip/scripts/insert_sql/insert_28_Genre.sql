INSERT INTO Genre (genre_id,genre_name,created_id,created_at,updated_id,updated_at) VALUES ('1','和風','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Genre (genre_id,genre_name,created_id,created_at,updated_id,updated_at) VALUES ('2','洋風','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Genre (genre_id,genre_name,created_id,created_at,updated_id,updated_at) VALUES ('3','中華風','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Genre (genre_id,genre_name,created_id,created_at,updated_id,updated_at) VALUES ('4','アジア風','1','2014-11-10 17:10:36.000','1','2016-11-11 00:00:00.000');
INSERT INTO Genre (genre_id,genre_name,created_id,created_at,updated_id,updated_at) VALUES ('5','その他','1','2014-04-10 00:00:00.000','1','2014-11-10 17:10:14.000');
