INSERT INTO Roles (role_id,role_name,created_id,created_at,updated_id,updated_at) VALUES ('1','参照ユーザ','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
INSERT INTO Roles (role_id,role_name,created_id,created_at,updated_id,updated_at) VALUES ('2','献立登録・チェック者用','1','2016-11-11 14:26:08.000','4','2016-12-13 20:49:53.000');
INSERT INTO Roles (role_id,role_name,created_id,created_at,updated_id,updated_at) VALUES ('3','献立・レシピチェックのみユーザ用','1','2016-11-17 18:54:42.000','1','2016-11-17 18:54:42.000');
