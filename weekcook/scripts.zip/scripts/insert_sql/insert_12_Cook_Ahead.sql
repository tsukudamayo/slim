INSERT INTO Cook_Ahead (cook_ahead_id,cook_ahead,created_id,created_at,updated_id,updated_at) VALUES ('1','下準備あり','1','2014-04-10 00:00:00.000','1','2014-11-13 10:40:57.000');
INSERT INTO Cook_Ahead (cook_ahead_id,cook_ahead,created_id,created_at,updated_id,updated_at) VALUES ('2','下準備なし','1','2014-04-10 00:00:00.000','1','2014-11-13 10:41:00.000');
INSERT INTO Cook_Ahead (cook_ahead_id,cook_ahead,created_id,created_at,updated_id,updated_at) VALUES ('3','作り置き','1','2014-04-10 00:00:00.000','1','2016-11-11 00:00:00.000');
